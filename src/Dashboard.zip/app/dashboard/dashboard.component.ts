import { Component} from '@angular/core';
import {FormControl} from '@angular/forms';
import {ChangeDetectionStrategy} from '@angular/core';
import { DataserviceService } from '../dataservice.service';
import { CdkDrag, CdkDragEnd, CdkDragMove, CdkDragStart, CdkDragDrop, transferArrayItem } from '@angular/cdk/drag-drop';



interface Task_Array {
  Title:string,
  Date: string,
  Assigned:string,
  Status:string,
  color:String,
}

                                                                                                                  
@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css'],
  changeDetection: ChangeDetectionStrategy.OnPush,
})


export class DashboardComponent{
  Task_Array:any[]= [
    {
      Title:"First Task",
      Date: "17/03/2023",
      Assigned:"Samuel Munyagah",
      status:"Complete"
    },

    {
      Title:"Second Task5",
      Date: "17/03/2023",
      Assigned:"Samuel Munyagah",
      status:"Incomplete"
    },
    {
      Title:"Second Task1",
      Date: "17/03/2023",
      Assigned:"Samuel Munyagah",
      status:"Complete"
    },
     ];
  Completed:any[] = this.Task_Array
constructor(public task_data:DataserviceService){

}

// onDragStart(event:
//   {target:{style:{opacity:number;};};}) {
//   console.log(`starting`,event);
//   event.preventDefault();

// }

onDragStart(event:CdkDragStart) {
  console.log('drag start', event)
  // event.preventDefault();
  console.log("Hellooooo")
}

onDrag(event: CdkDragMove) {
  // console.log('dragging', event)
  // event.preventDefault();
  
}

onDragEnd(event: CdkDragEnd) {
  console.log('drag end', event);
  // event.preventDefault();
}

selected ='boardview'
toppings = new FormControl('');


drop(event: CdkDragDrop<any>){
  console.log('dropped', event);
  console.log('dropped prev', event.previousContainer.data);
  console.log('dropped curr', event.container.data);
  console.log('dropped index', event.previousIndex);
  
  transferArrayItem(event.previousContainer.data, event.container.data, event.previousIndex, event.currentIndex)
}
}

// @InputEvent()
// id:String
//   event = document.createEvent("Event"),

//   // Define that the event name is 'build'.
//   event.initEvent("build", true, true),
  
//   // Listen for the event.
//   elem.addEventListener(
//     "build",
//     (e:any) => {
//       // e.target matches elem
//     },
//     false
//   )
  
//   // target can be any Element or other EventTarget.
//   elem.dispatchEvent(event)

